export default [
    {
        name: "artePrueba",
        description: 'categoria de prueba relacionada al arte'
    },
    {
        name: "cienciaPrueba",
        description: 'categoria de prueba relacionada con la ciencia'
    }
]