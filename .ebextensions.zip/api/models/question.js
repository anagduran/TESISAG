import mongoose from 'mongoose'

const questionSchema =  mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    question: {type: String},
    options:[{type: String}],
    answer: {type: String},
    level:  {type: String, lvl: ["High", "Medium", "Low"]}, 
    status: {type: String, lvl: ["available", "not available"]},
    category: [{type: mongoose.Schema.Types.ObjectId, ref: 'category'}],
    created_at: {type: Date}
},{ 
    versionKey: false
});

const question =mongoose.model('question', questionSchema, 'question')


module.exports = question;